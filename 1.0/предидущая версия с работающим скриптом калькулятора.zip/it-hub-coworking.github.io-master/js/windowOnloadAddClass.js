// window.onload = function() {
//     var element = document.querySelectorAll("path");
//     element.addClass("mystyle");
// };