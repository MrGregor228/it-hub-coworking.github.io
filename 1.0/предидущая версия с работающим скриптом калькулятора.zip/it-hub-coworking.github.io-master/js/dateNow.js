var d = new Date();

document.write(d.getFullYear());